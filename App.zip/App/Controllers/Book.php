

<?php

class Book {

    public function updateChapter() {
        require "../App/Views/Admin/update-chapter.php";
    }
    
}

?>